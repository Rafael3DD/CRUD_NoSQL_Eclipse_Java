import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDB {
	
	
	public static void main(String [] args) {
 
		MongoClient mongoClient = new MongoClient("localhost",27017);
		MongoDatabase mdb = mongoClient.getDatabase("mercado");
		MongoCollection<Document> collection = mdb.getCollection("produto");
		Document document = new Document("_id", 99).append("nome","miojo").append("preco",2.00);
		collection.insertOne(document);


	
	}
	
	
}
