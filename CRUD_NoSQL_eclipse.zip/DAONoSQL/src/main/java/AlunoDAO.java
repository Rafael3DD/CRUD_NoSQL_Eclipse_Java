

import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;


public class AlunoDAO {
	static MongoClient mongoClient = new MongoClient("localhost",27017);
	static MongoDatabase mdb = mongoClient.getDatabase("escola");
	static MongoCollection<Document> collection = mdb.getCollection("aluno");
	
	
	public static void main(String [] args) {
		Aluno aluno = new Aluno("Torta", 5, "3322");
		InsereAluno(aluno.getNome(), aluno.getNota(), aluno.getRA());
		Remover("202020202020");
	}
	
	//insere
		public static void InsereAluno(String nome, float nota, String RA){
			Document document = new Document("nome", nome).append("nota",nota).append("RA",RA);
			collection.insertOne(document);
		}

		//remove
		public  static void Remover(String RA) {
			collection.deleteOne(eq("RA", RA));

		}

		//altera nota
		public static void AlteraNota(String RA, float nota) {
			collection.updateOne(eq("RA", RA),
					new Document("$set",
							new Document("nota", nota)));
		}


		//buca nota
		public static void BuscaNota(String RA) {
			MongoCursor<Document> dados = collection.find(eq("RA", RA)).iterator();
			try {
				while(dados.hasNext()) {
					Document atual = dados.next();
					System.out.println("Nome: " + atual.get("nome"));
					System.out.println("Nota: " + atual.get("nota"));
					System.out.println("RA: " +atual.get("RA"));
				}
			} finally {
				dados.close();
			}
		}
}
